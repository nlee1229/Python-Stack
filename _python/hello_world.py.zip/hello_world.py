print("Hello World!")

x = "Hello Python"
print(x)
y = 42
print(y)
