from django.apps import AppConfig


class MarbleConfig(AppConfig):
    name = 'marble'
