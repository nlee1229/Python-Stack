from django.apps import AppConfig


class MainFirstConfig(AppConfig):
    name = 'main_first'
