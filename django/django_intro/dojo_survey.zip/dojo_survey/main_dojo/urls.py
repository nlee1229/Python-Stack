from django.urls import path

from . import views

urlpatterns = [
    path('', views.index),
    path('result',views.index2),
    path('goback', views.goback),
]