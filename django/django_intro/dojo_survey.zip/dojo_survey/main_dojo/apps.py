from django.apps import AppConfig


class MainDojoConfig(AppConfig):
    name = 'main_dojo'
