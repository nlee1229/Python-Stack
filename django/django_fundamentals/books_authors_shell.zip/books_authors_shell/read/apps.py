from django.apps import AppConfig


class ReadConfig(AppConfig):
    name = 'read'
